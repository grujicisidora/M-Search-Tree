
public class DotFile {

	public String toDot(MSearchTree tree, MNode node) {
		
		String res = "digraph MSearchTree {";
		for(Integer i = 0; i < tree.M; i++) {
			res += "\"";
			res += tree.readNode(node);
			res += "\"";
			res += "->";
			res += "\"";
			if (tree.readNode(node.children[i]) == " Empty ") 
				res = res + "Node " + i.toString() + ":" + tree.readNode(node.children[i]);
			else 
				res += tree.readNode(node.children[i]);
			res += "\"";
			res += ";";
		}
		res += "}";
		return res;
	}
	
	
}
