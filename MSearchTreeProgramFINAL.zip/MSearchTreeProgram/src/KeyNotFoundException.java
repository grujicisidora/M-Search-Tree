
public class KeyNotFoundException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	KeyNotFoundException(String s){
		super(s);
	}

}
