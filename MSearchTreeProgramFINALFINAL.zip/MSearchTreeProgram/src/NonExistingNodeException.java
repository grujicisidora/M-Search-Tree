
public class NonExistingNodeException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	NonExistingNodeException(String s){
		super(s);
	}

}
