
public class EmptyNodeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	EmptyNodeException(String s){
		super(s);
	}
	
}
